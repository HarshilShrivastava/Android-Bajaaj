package com.example.fitnessapp.storage;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.fitnessapp.model_class.Data;
import com.example.fitnessapp.model_class.User;

public class SharedPreferenceManager {
    private static final String SHARED_PREF_NAME = "my_shared_pref";

    private static SharedPreferenceManager mInstance;
    private Context mCtx;

    private SharedPreferenceManager(Context mCtx) {
        this.mCtx = mCtx;
    }


    public static synchronized SharedPreferenceManager getInstance(Context mCtx) {
        if (mInstance == null) {
            mInstance = new SharedPreferenceManager(mCtx);
        }
        return mInstance;
    }

    public void saveStatistics(Data data){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString ( "gender" , data.getGender ());
        editor.putFloat ( "weight", data.getWeight () );
        editor.putFloat ( "height", data.getHeight () );
        editor.putString ( "goals", data.getGoals () );
        editor.putString ( "activity", data.getActivity () );
        editor.putInt ( "age", data.getAge () );
        editor.putFloat ( "bMI", data.getBMI () );
        editor.putInt ( "condition", data.getCondition () );
        editor.apply ();

    }

    public boolean isSaved(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString ("Gender", null) != null;

    }

    public Data getUserData(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new Data(
//                sharedPreferences.getString ( "gender", null ),
//                sharedPreferences.getFloat ( "weight", -1 ),
//                sharedPreferences.getFloat ( "height", -1 ),
//                sharedPreferences.getString ("goals", null),
//                sharedPreferences.getString ( "activity", null ),
//                sharedPreferences.getInt ( "age", -1),
//                sharedPreferences.getFloat ( "bMI", -1 ),
//                sharedPreferences.getInt ( "condition", -1 )
//
//                sharedPreferences.getString ( "gender", null ),
//                sharedPreferences.getFloat ( "weight", -1 ),
//                sharedPreferences.getFloat ( "height", -1 ),
//                sharedPreferences.getString ("goals", null),
//                sharedPreferences.getString ( "activity", null ),
//                sharedPreferences.getInt ( "age", -1),
//                sharedPreferences.getFloat ( "bMI", -1 ),
//                sharedPreferences.getInt ( "condition", -1 )

        );

    }


    public void saveUser(User user) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("token", user.getToken ()); //user object is null here simple nullpointerexception
        editor.putString("username", user.getUsername ());
        editor.putString("email", user.getEmail());
        editor.putInt("id", user.getId());
        editor.apply();

    }

    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString ("token", null) != null;
    }






    public User getUser() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);

        return new User(
                sharedPreferences.getString("token", null),
                sharedPreferences.getString("username", null),
                sharedPreferences.getString("email", null),
                sharedPreferences.getInt("id", -1)
        );
    }

    public void clear() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }






}
