package com.example.fitnessapp.model_class;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("Gender")
    @Expose
    private String gender;
    @SerializedName("Weight")
    @Expose
    private Float weight;
    @SerializedName("Height")
    @Expose
    private Float height;
    @SerializedName("Goals")
    @Expose
    private String goals;
    @SerializedName("Activity")
    @Expose
    private String activity;
    @SerializedName("Age")
    @Expose
    private Integer age;
    @SerializedName("BMI")
    @Expose
    private Float bMI;
    @SerializedName("Condition")
    @Expose
    private Integer condition;

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public String getGoals() {
        return goals;
    }

    public void setGoals(String goals) {
        this.goals = goals;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Float getBMI() {
        return bMI;
    }

    public void setBMI(Float bMI) {
        this.bMI = bMI;
    }

    public Integer getCondition() {
        return condition;
    }

    public void setCondition(Integer condition) {
        this.condition = condition;
    }

}